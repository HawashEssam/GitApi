package com.example.moviemvvm.Pojo;

public class MovieModel {
    String movieName;

    public MovieModel(String movieName) {
        this.movieName = movieName;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }
}
