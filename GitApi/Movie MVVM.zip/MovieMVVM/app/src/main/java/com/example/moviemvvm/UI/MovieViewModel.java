package com.example.moviemvvm.UI;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.moviemvvm.Pojo.MovieModel;


public class MovieViewModel extends ViewModel {

  public   MutableLiveData<String> movieNameMutableLiveData=new MutableLiveData<>();


    public void getMovieName(){
        String movieName=getMovieFromDatabase().getMovieName();
        movieNameMutableLiveData.setValue(movieName);
    }
    private MovieModel getMovieFromDatabase(){
        return new MovieModel("Black Widow");

    }
}
